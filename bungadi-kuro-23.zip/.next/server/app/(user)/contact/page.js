(() => {
var exports = {};
exports.id = 977;
exports.ids = [977];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 89871:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/client");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 71267:
/***/ ((module) => {

"use strict";
module.exports = require("worker_threads");

/***/ }),

/***/ 4288:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(user)',
        {
        children: [
        'contact',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 31538)), "C:\\Users\\KURO\\Code\\bungadi\\bungadi-kuro-23\\src\\app\\(user)\\contact\\page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 93549)), "C:\\Users\\KURO\\Code\\bungadi\\bungadi-kuro-23\\src\\app\\(user)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82819))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 54232)), "C:\\Users\\KURO\\Code\\bungadi\\bungadi-kuro-23\\src\\app\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82819))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\KURO\\Code\\bungadi\\bungadi-kuro-23\\src\\app\\(user)\\contact\\page.tsx"];
    
    const originalPathname = "/(user)/contact/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 7880:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 87011))

/***/ }),

/***/ 87011:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ContactPage),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/dom/motion.mjs + 202 modules
var motion = __webpack_require__(71963);
// EXTERNAL MODULE: ./node_modules/@emailjs/browser/cjs/index.js
var cjs = __webpack_require__(15366);
// EXTERNAL MODULE: ./node_modules/react-redux/lib/index.js
var lib = __webpack_require__(1560);
// EXTERNAL MODULE: ./src/hoc/SectionWrapper.tsx
var SectionWrapper = __webpack_require__(40455);
// EXTERNAL MODULE: ./src/utils/motion.ts
var utils_motion = __webpack_require__(19751);
// EXTERNAL MODULE: ./node_modules/@react-three/fiber/dist/react-three-fiber.cjs.prod.js
var react_three_fiber_cjs_prod = __webpack_require__(2028);
// EXTERNAL MODULE: ./node_modules/@react-three/drei/index.cjs.js
var index_cjs = __webpack_require__(47320);
// EXTERNAL MODULE: ./src/components/Loader.tsx
var Loader = __webpack_require__(8743);
;// CONCATENATED MODULE: ./src/components/canvas/LogoBig.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 




const Sta = ()=>{
    const earth = (0,index_cjs/* useGLTF */.LDd)("./bungadi3d/logo.gltf");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("mesh", {
        castShadow: true,
        receiveShadow: true,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("ambientLight", {
                intensity: 0.25
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("directionalLight", {
                position: [
                    0,
                    0,
                    0.05
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("primitive", {
                object: earth.scene,
                scale: 2.5,
                "position-y": -3,
                "rotation-y": 0
            })
        ]
    });
};
const LogoBigCanvas = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(react_three_fiber_cjs_prod.Canvas, {
        shadows: true,
        frameloop: "demand",
        dpr: [
            1,
            2
        ],
        gl: {
            preserveDrawingBuffer: true
        },
        camera: {
            fov: 45,
            near: 0.1,
            far: 200,
            position: [
                -4,
                3,
                6
            ]
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Suspense, {
            fallback: /*#__PURE__*/ jsx_runtime_.jsx(Loader/* default */.Z, {}),
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(index_cjs/* OrbitControls */.zxs, {
                    autoRotate: true,
                    enableZoom: false,
                    maxPolarAngle: Math.PI / 2,
                    minPolarAngle: Math.PI / 2
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Sta, {}),
                /*#__PURE__*/ jsx_runtime_.jsx(index_cjs/* Preload */.qaH, {
                    all: true
                })
            ]
        })
    });
};
/* harmony default export */ const LogoBig = (LogoBigCanvas);

// EXTERNAL MODULE: ./node_modules/react-icons/bs/index.esm.js
var index_esm = __webpack_require__(75484);
;// CONCATENATED MODULE: ./src/components/MySocialLink.tsx




const MySocialLink = ()=>{
    const { darkMode } = (0,lib.useSelector)((state)=>state.darkMode);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "mt-16 text-center",
                children: "feel free to visit my social media"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "mb-4 flex justify-center flex-row lg:mb-0",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "https://github.com/Bung-Adi",
                        className: "group rounded-lg border border-transparent px-2 py-2 mx-2 transition-colors hover:border-gray-300 hover:bg-gray-100 hover:dark:border-neutral-700 hover:dark:bg-neutral-800/30",
                        target: "_blank",
                        rel: "noopener noreferrer",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "mb-0 transition-transform group-hover:scale-125 motion-reduce:transform-none",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsGithub */.rFR, {
                                color: `${darkMode ? "white" : "black"}`
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "https://www.linkedin.com/in/muhammad-aziz-abdillah-8980b41a0/",
                        className: "group rounded-lg border border-transparent px-2 py-2 mx-2 transition-colors hover:border-gray-300 hover:bg-gray-100 hover:dark:border-neutral-700 hover:dark:bg-neutral-800/30",
                        target: "_blank",
                        rel: "noopener noreferrer",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "mb-0 transition-transform group-hover:scale-125 motion-reduce:transform-none",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsLinkedin */.NQh, {
                                color: `${darkMode ? "white" : "black"}`
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "https://twitter.com/bungadi26",
                        className: "group rounded-lg border border-transparent px-2 py-2 mx-2 transition-colors hover:border-gray-300 hover:bg-gray-100 hover:dark:border-neutral-700 hover:dark:bg-neutral-800/30",
                        target: "_blank",
                        rel: "noopener noreferrer",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "mb-0 transition-transform group-hover:scale-125 motion-reduce:transform-none",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsTwitter */.meP, {
                                color: `${darkMode ? "white" : "black"}`
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "https://www.facebook.com/am.19000/",
                        className: "group rounded-lg border border-transparent px-2 py-2 mx-2 transition-colors hover:border-gray-300 hover:bg-gray-100 hover:dark:border-neutral-700 hover:dark:bg-neutral-800/30",
                        target: "_blank",
                        rel: "noopener noreferrer",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "mb-0 transition-transform group-hover:scale-125 motion-reduce:transform-none",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsFacebook */.k1O, {
                                color: `${darkMode ? "white" : "black"}`
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "https://www.instagram.com/adi26r/",
                        className: "group rounded-lg border border-transparent px-2 py-2 mx-2 transition-colors hover:border-gray-300 hover:bg-gray-100 hover:dark:border-neutral-700 hover:dark:bg-neutral-800/30",
                        target: "_blank",
                        rel: "noopener noreferrer",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "mb-0 transition-transform group-hover:scale-125 motion-reduce:transform-none",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsInstagram */.Vs6, {
                                color: `${darkMode ? "white" : "black"}`
                            })
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_MySocialLink = (MySocialLink);

;// CONCATENATED MODULE: ./src/components/Contact.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 








const Contact = ()=>{
    const { darkMode } = (0,lib.useSelector)((state)=>state.darkMode);
    const formRef = (0,react_.useRef)(null);
    const [form, setForm] = (0,react_.useState)({
        name: "",
        email: "",
        message: ""
    });
    const [loading, setLoading] = (0,react_.useState)(false);
    const handleChange = (e)=>{
        const { target } = e;
        const { name, value } = target;
        setForm({
            ...form,
            [name]: value
        });
    };
    const handleSubmit = (e)=>{
        e.preventDefault();
        setLoading(true);
        if (true) {
            cjs/* default.sendForm */.ZP.sendForm("service_w7grmab", "template_dtfdz0g", e.currentTarget, "gUYXJysK83WnZifgi").then(()=>{
                setLoading(false);
                alert("Thank you. I will get back to you as soon as possible.");
                setForm({
                    name: "",
                    email: "",
                    message: ""
                });
            }, (error)=>{
                setLoading(false);
                console.error(error);
                alert("Ahh, something went wrong. Please try again.");
            });
        } else {}
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex xl:flex-row flex-col-reverse gap-10 overflow-hidden",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion */.E.div, {
                variants: (0,utils_motion/* slideIn */.Ym)("left", "tween", 0.2, 1),
                id: "contact-form",
                className: `flex-[0.75] m-8 md:m-16 2xl:m-8 ${darkMode ? "bg-black-100 text-white-100 shadow-card1" : "bg-white-100 text-black-100 shadow-card0"} p-8 rounded-2xl`,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "font-medium lg:text-2xl sm:text-xl xs:text-lg text-base mt-2",
                        children: "Get in touch"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        className: "font-black lg:text-5xl sm:text-3xl xs:text-2xl text-xl mt-2",
                        children: "Contact."
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                        ref: formRef,
                        onSubmit: handleSubmit,
                        className: "mt-12 flex flex-col gap-8",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                className: "flex flex-col",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-medium mb-4",
                                        children: "Your Name"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "text",
                                        name: "name",
                                        value: form.name,
                                        onChange: handleChange,
                                        placeholder: "What's your good name?",
                                        className: `${darkMode ? "bg-black-100 shadow-inset0" : "bg-white-100 shadow-inset1"} py-4 px-6 placeholder:text-secondary rounded-lg outline-none border-none font-medium`
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                className: "flex flex-col",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-medium mb-4",
                                        children: "Your email"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "email",
                                        name: "email",
                                        value: form.email,
                                        onChange: handleChange,
                                        placeholder: "What's your web address?",
                                        className: `${darkMode ? "bg-black-100 shadow-inset0" : "bg-white-100 shadow-inset1"} py-4 px-6 placeholder:text-secondary text-white rounded-lg outline-none border-none font-medium`
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                className: "flex flex-col",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-medium mb-4",
                                        children: "Your Message"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                                        rows: 7,
                                        name: "message",
                                        value: form.message,
                                        onChange: handleChange,
                                        placeholder: "What you want to say?",
                                        className: `${darkMode ? "bg-black-100 shadow-inset0" : "bg-white-100 shadow-inset1"} py-4 px-6 placeholder:text-secondary text-white rounded-lg outline-none border-none font-medium`
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                type: "submit",
                                className: "flex flex-row items-center justify-center gap-2 rounded bg-button-gradien px-6 py-2.5    text-xs font-medium uppercase leading-tight text-white shadow-white    transition duration-150 ease-in-out active:bg-primary-800 active:shadow-lg",
                                children: loading ? "Sending..." : "Send"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "xl:hidden",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(components_MySocialLink, {})
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion */.E.div, {
                variants: (0,utils_motion/* slideIn */.Ym)("right", "tween", 0.2, 1),
                className: "xl:flex-1 xl:h-auto md:max-h-[550px] max-h-screen",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(LogoBig, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "xl:hidden absolute xs:bottom-8 bottom-16 w-full flex justify-center items-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            href: "#contact-form",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-[35px] h-[64px] rounded-3xl border-4 border-secondary flex justify-center items-start p-2",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.div, {
                                    animate: {
                                        y: [
                                            0,
                                            24,
                                            0
                                        ]
                                    },
                                    transition: {
                                        duration: 1.5,
                                        repeat: Infinity,
                                        repeatType: "loop"
                                    },
                                    className: "w-3 h-3 rounded-full bg-secondary mb-1"
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "hidden xl:block",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(components_MySocialLink, {})
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_Contact = ((0,SectionWrapper/* default */.Z)(Contact, "contact"));

// EXTERNAL MODULE: ./node_modules/maath/dist/maath.cjs.js
var maath_cjs = __webpack_require__(37937);
;// CONCATENATED MODULE: ./src/components/canvas/Stars.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 




let width;
let height;
const Stars = (props)=>{
    const ref = (0,react_.useRef)(null);
    // const [sphere] = useState(() => random.inSphere(new Float32Array(5000), { radius: 1.2 }));
    const sphere = new Float32Array(maath_cjs.random.inSphere(new Float32Array(5000), {
        radius: 1.2
    }));
    const numPoints = Number(width * height / 2);
    const positions = new Float32Array(numPoints * 3);
    (0,react_three_fiber_cjs_prod.useFrame)((state, delta)=>{
        if (ref.current) {
            ref.current.rotation.x -= delta / 10;
            ref.current.rotation.y -= delta / 15;
        }
    });
    return /*#__PURE__*/ jsx_runtime_.jsx("group", {
        rotation: [
            0,
            0,
            Math.PI / 4
        ],
        children: /*#__PURE__*/ jsx_runtime_.jsx(index_cjs/* Points */.woe, {
            ref: ref,
            positions: sphere,
            stride: 3,
            frustumCulled: true,
            ...props,
            children: /*#__PURE__*/ jsx_runtime_.jsx(index_cjs/* PointMaterial */.CBW, {
                transparent: true,
                color: "#f272c8",
                size: 0.002,
                sizeAttenuation: true,
                depthWrite: false
            })
        })
    });
};
const StarsCanvas = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full h-auto absolute inset-0 z-[-1]",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_three_fiber_cjs_prod.Canvas, {
            camera: {
                position: [
                    0,
                    0,
                    1
                ]
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(react_.Suspense, {
                    fallback: null,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Stars, {})
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(index_cjs/* Preload */.qaH, {
                    all: true
                })
            ]
        })
    });
};
/* harmony default export */ const canvas_Stars = (StarsCanvas);

;// CONCATENATED MODULE: ./src/app/(user)/contact/page.tsx
/* __next_internal_client_entry_do_not_use__ metadata,default auto */ 




const metadata = {
    title: "Contact 'Adi' Muhammad Aziz Abdillah"
};
function ContactPage() {
    const { darkMode } = (0,lib.useSelector)((state)=>state.darkMode);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: `relative z-0 ${darkMode ? "bg-black-100" : "bg-white-100"}`,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "relative z-0",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(components_Contact, {}),
                /*#__PURE__*/ jsx_runtime_.jsx(canvas_Stars, {})
            ]
        })
    });
}


/***/ }),

/***/ 40455:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(71963);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(19751);



const SectionWrapper = (Component, idName)=>function HOC() {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__/* .motion */ .E.section, {
            variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_2__/* .staggerContainer */ .Jm)(Component, idName),
            initial: "hidden",
            whileInView: "show",
            viewport: {
                once: true,
                amount: 0.25
            },
            className: "sm:w-4/5 max-w-7xl ml-auto relative z-0",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "hash-span",
                    id: idName,
                    children: "\xa0"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {})
            ]
        });
    };
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SectionWrapper);


/***/ }),

/***/ 31538:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   metadata: () => (/* binding */ e0)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Users\KURO\Code\bungadi\bungadi-kuro-23\src\app\(user)\contact\page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;

const e0 = proxy["metadata"];


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [763,725,332,593,608,206,861,751], () => (__webpack_exec__(4288)));
module.exports = __webpack_exports__;

})();