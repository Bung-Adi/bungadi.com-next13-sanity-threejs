(() => {
var exports = {};
exports.id = 742;
exports.ids = [742];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 89871:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/client");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 14300:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 41808:
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ 88849:
/***/ ((module) => {

"use strict";
module.exports = require("node:http");

/***/ }),

/***/ 22286:
/***/ ((module) => {

"use strict";
module.exports = require("node:https");

/***/ }),

/***/ 41041:
/***/ ((module) => {

"use strict";
module.exports = require("node:url");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 63477:
/***/ ((module) => {

"use strict";
module.exports = require("querystring");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 24404:
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 71267:
/***/ ((module) => {

"use strict";
module.exports = require("worker_threads");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 53323:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(user)',
        {
        children: [
        'post',
        {
        children: [
        '[slug]',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 86127)), "C:\\Users\\KURO\\Code\\bungadi\\bungadi-kuro-23\\src\\app\\(user)\\post\\[slug]\\page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 93549)), "C:\\Users\\KURO\\Code\\bungadi\\bungadi-kuro-23\\src\\app\\(user)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82819))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 54232)), "C:\\Users\\KURO\\Code\\bungadi\\bungadi-kuro-23\\src\\app\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82819))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\KURO\\Code\\bungadi\\bungadi-kuro-23\\src\\app\\(user)\\post\\[slug]\\page.tsx"];
    
    const originalPathname = "/(user)/post/[slug]/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 16983:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 44069))

/***/ }),

/***/ 44069:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ blog_BlogContent)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/@portabletext/react/dist/react-portable-text.cjs.mjs
var react_portable_text_cjs = __webpack_require__(453);
// EXTERNAL MODULE: ./src/lib/urlFor.ts + 1 modules
var urlFor = __webpack_require__(75422);
;// CONCATENATED MODULE: ./src/components/blog/RichTextComponents.tsx



const RichTextComponents = {
    types: {
        image: ({ value })=>{
            return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "relative w-full h-96 m-10 mx-auto",
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    className: "object-contain",
                    src: (0,urlFor/* default */.Z)(value).url(),
                    alt: "blog post image",
                    sizes: "(max-width: 768px) 100%, (max-width: 1200px) 50%, 33vw",
                    fill: true
                })
            });
        }
    },
    list: {
        // Ex. 1: customizing common list types
        bullet: ({ children })=>/*#__PURE__*/ jsx_runtime_.jsx("ul", {
                className: "ml-10 py-5 list-disc space-y-5",
                children: children
            }),
        number: ({ children })=>/*#__PURE__*/ jsx_runtime_.jsx("ol", {
                className: "mt-lg list-decimal",
                children: children
            }),
        // Ex. 2: rendering custom lists
        checkmarks: ({ children })=>/*#__PURE__*/ jsx_runtime_.jsx("ol", {
                className: "m-auto text-lg",
                children: children
            })
    },
    block: {
        // Ex. 1: customizing common block types
        h1: ({ children })=>/*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "text-5xl py-10 font-bold",
                children: children
            }),
        h2: ({ children })=>/*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "text-4xl py-10 font-bold",
                children: children
            }),
        h3: ({ children })=>/*#__PURE__*/ jsx_runtime_.jsx("h3", {
                className: "text-3xl py-10 font-bold",
                children: children
            }),
        h4: ({ children })=>/*#__PURE__*/ jsx_runtime_.jsx("h4", {
                className: "text-2xl py-10 font-bold",
                children: children
            }),
        blockquote: ({ children })=>/*#__PURE__*/ jsx_runtime_.jsx("blockquote", {
                className: "border-l-[#97DAEE] border-l-4 pl-5 py-5 my-5",
                children: children
            })
    },
    marks: {
        // Ex. 1: custom renderer for the em / italics decorator
        em: ({ children })=>/*#__PURE__*/ jsx_runtime_.jsx("em", {
                className: "text-gray-600 font-semibold",
                children: children
            }),
        // Ex. 2: rendering a custom `link` annotation
        link: ({ value, children })=>{
            const target = (value?.href || "").startsWith("http") ? "_blank" : undefined;
            return /*#__PURE__*/ jsx_runtime_.jsx("a", {
                href: value?.href,
                rel: target,
                className: "underline decoration-[#97DAEE] hover:decoration-black",
                children: children
            });
        }
    }
};

// EXTERNAL MODULE: ./node_modules/react-redux/lib/index.js
var lib = __webpack_require__(1560);
;// CONCATENATED MODULE: ./src/components/blog/BlogContent.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 






const BlogContent = (props)=>{
    const { darkMode } = (0,lib.useSelector)((state)=>state.darkMode);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("article", {
        className: `px-10 py-16 w-full sm:w-4/5 min-h-screen ml-0 sm:ml-[20%] ${darkMode ? "bg-black-100 text-white-100" : "bg-white-100 text-black-100"}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "space-y-2 border border-primary",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "relative min-h-56 flex flex-col md:flex-row justify-between",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "absolute top-0 w-full h-full opacity-10 blur-sm p-10",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: "object-cover object-left lg:object-center w-auto h-auto",
                                src: (0,urlFor/* default */.Z)(props.mainImage).url(),
                                alt: props.author.name,
                                sizes: "(max-width: 768px) 100%, (max-width: 1200px) 50%, 33vw",
                                fill: true
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                            className: "p-5 bg-primary w-full",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-col md:flex-row justify-between gap-y-5",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                    className: "text-4xl font-extrabold",
                                                    children: props.title
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: new Date(props._createdAt).toLocaleDateString("en-US", {
                                                        day: "numeric",
                                                        month: "long",
                                                        year: "numeric"
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex items-center justify-end space-x-2",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    className: "rounded-full",
                                                    src: (0,urlFor/* default */.Z)(props.author.image).url(),
                                                    alt: props.author.name,
                                                    width: 30,
                                                    height: 30
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: " w-auto",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                            className: "font-bold text-lg",
                                                            children: props.author.name
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {})
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                            className: "italic pt-10",
                                            children: props.description
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "flex items-center justify-end mt-auto space-x-2",
                                            children: props.categories.map((category)=>/*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "    px-3 py-1 rounded-full text-sm font-semibold mt-4",
                                                    children: category.title
                                                }, category._id))
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_portable_text_cjs/* PortableText */.YI, {
                value: props.body,
                components: RichTextComponents
            })
        ]
    });
};
/* harmony default export */ const blog_BlogContent = (BlogContent);


/***/ }),

/***/ 86127:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page),
  generateMetadata: () => (/* binding */ generateMetadata),
  generateStaticParams: () => (/* binding */ generateStaticParams),
  revalidate: () => (/* binding */ revalidate)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./src/lib/sanity.client.ts
var sanity_client = __webpack_require__(49002);
// EXTERNAL MODULE: ./node_modules/next-sanity/dist/index.cjs.js
var index_cjs = __webpack_require__(59407);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(21313);
;// CONCATENATED MODULE: ./src/components/blog/BlogContent.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\KURO\Code\bungadi\bungadi-kuro-23\src\components\blog\BlogContent.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const BlogContent = (__default__);
;// CONCATENATED MODULE: ./src/app/(user)/post/[slug]/page.tsx




// revalidate post page every 60s
const revalidate = 60;
async function generateMetadata({ params: { slug } }) {
    const query = index_cjs/* groq */.Ml`
        *[_type=='post' && slug.current == $slug][0]{
            ...,
            author->,
            categories[]->,
        }
    `;
    try {
        const post = await sanity_client/* client */.Lp.fetch(query, {
            slug
        });
        if (!post) {
            return {
                title: "not found",
                description: "page you are looking is not found"
            };
        }
        return {
            title: post.title,
            description: post.description
        };
    } catch (error) {
        return {
            title: "not found",
            description: "page you are looking is not found"
        };
    }
}
async function generateStaticParams() {
    const query = index_cjs/* groq */.Ml`
        *[_type=='post']{
            slug
        }`;
    const slugs = await sanity_client/* client */.Lp.fetch(query);
    const slugRoutes = slugs.map((slug)=>slug.slug.current);
    return slugRoutes.map((slug)=>({
            slug
        }));
}
async function Post({ params: { slug } }) {
    const query = index_cjs/* groq */.Ml`
        *[_type=='post' && slug.current == $slug][0]{
            ...,
            author->,
            categories[]->,
        }
    `;
    const post = await sanity_client/* client */.Lp.fetch(query, {
        slug
    });
    return /*#__PURE__*/ jsx_runtime_.jsx(BlogContent, {
        ...post
    }, post._id);
}
/* harmony default export */ const page = (Post);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [763,725,332,593,263,573,453,206,861,687], () => (__webpack_exec__(53323)));
module.exports = __webpack_exports__;

})();