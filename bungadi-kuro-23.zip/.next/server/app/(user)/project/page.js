(() => {
var exports = {};
exports.id = 153;
exports.ids = [153];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 89871:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/client");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 71267:
/***/ ((module) => {

"use strict";
module.exports = require("worker_threads");

/***/ }),

/***/ 72368:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(user)',
        {
        children: [
        'project',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 65616)), "C:\\Users\\KURO\\Code\\bungadi\\bungadi-kuro-23\\src\\app\\(user)\\project\\page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 93549)), "C:\\Users\\KURO\\Code\\bungadi\\bungadi-kuro-23\\src\\app\\(user)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82819))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 54232)), "C:\\Users\\KURO\\Code\\bungadi\\bungadi-kuro-23\\src\\app\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82819))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\KURO\\Code\\bungadi\\bungadi-kuro-23\\src\\app\\(user)\\project\\page.tsx"];
    
    const originalPathname = "/(user)/project/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 25298:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 54473))

/***/ }),

/***/ 54473:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ProjectPage),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/react-tilt/dist/index.js
var dist = __webpack_require__(54619);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/dom/motion.mjs + 202 modules
var motion = __webpack_require__(71963);
// EXTERNAL MODULE: ./node_modules/react-redux/lib/index.js
var lib = __webpack_require__(1560);
// EXTERNAL MODULE: ./src/hoc/SectionWrapper.tsx
var SectionWrapper = __webpack_require__(40455);
// EXTERNAL MODULE: ./src/utils/constants.ts
var constants = __webpack_require__(49711);
// EXTERNAL MODULE: ./src/utils/motion.ts
var utils_motion = __webpack_require__(19751);
;// CONCATENATED MODULE: ./src/components/Project.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 








const github = "/assets/github.png";
const ProjectCard = ({ index, name, description, tags, image, source_code_link, dark })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.div, {
        variants: (0,utils_motion/* fadeIn */.Ji)("up", "spring", index * 0.5, 0.75),
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dist/* Tilt */.C, {
            options: {
                max: 45,
                scale: 1,
                speed: 450
            },
            className: `${dark ? "bg-black-100" : "bg-white-100"} border-2 border-secondary p-5 rounded-2xl sm:w-[360px] w-full`,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "relative w-full h-[230px]",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Suspense, {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: image,
                                width: 1000,
                                height: 1000,
                                alt: "project_image",
                                className: "w-full h-full object-cover rounded-2xl"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "absolute inset-0 flex justify-end m-3 card-img_hover",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                onClick: ()=>window.open(source_code_link, "_blank"),
                                className: "black-gradient w-10 h-10 rounded-full flex justify-center items-center cursor-pointer",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: github,
                                    alt: "source code",
                                    className: "w-1/2 h-1/2 object-contain"
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: `mt-5 ${dark ? "text-white-100" : "text-black-100"}`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            className: "font-bold text-[24px]",
                            children: name
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "mt-2 text-[14px]",
                            children: description
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "mt-4 flex flex-wrap gap-2",
                    children: tags.map((tag)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            className: `text-[14px] ${tag.color}`,
                            children: [
                                "#",
                                tag.name
                            ]
                        }, `${name}-${tag.name}`))
                })
            ]
        })
    });
};
const Works = ()=>{
    const { darkMode } = (0,lib.useSelector)((state)=>state.darkMode);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `sm:px-16 px-6 mt-8 ${darkMode ? "text-white-100" : "text-black-100"}`,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion */.E.div, {
                variants: (0,utils_motion/* textVariant */.wt)(1),
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "font-medium lg:text-2xl sm:text-xl xs:text-lg text-base mt-2",
                        children: "My work"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "font-black lg:text-5xl sm:text-3xl xs:text-2xl text-xl mt-2",
                        children: "Projects."
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-full flex",
                children: /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.p, {
                    variants: (0,utils_motion/* fadeIn */.Ji)("", "", 0.1, 1),
                    className: "mt-3 text-[17px] max-w-3xl leading-[30px]",
                    children: "Following projects showcases my skills and experience through real-world examples of my work. Each project is briefly described with links to code repositories and live demos in it. It reflects my ability to solve complex problems, work with different technologies, and manage projects effectively."
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "mt-20 flex flex-wrap gap-7",
                children: constants/* projects */.q.map((project, index)=>/*#__PURE__*/ jsx_runtime_.jsx(ProjectCard, {
                        index: index,
                        ...project,
                        dark: darkMode
                    }, `project-${index}`))
            })
        ]
    });
};
/* harmony default export */ const Project = ((0,SectionWrapper/* default */.Z)(Works, ""));

;// CONCATENATED MODULE: ./src/app/(user)/project/page.tsx
/* __next_internal_client_entry_do_not_use__ metadata,default auto */ 



const metadata = {
    title: "What Projects 'Adi' Muhammad Aziz Abdillah ever contribute"
};
function ProjectPage() {
    const { darkMode } = (0,lib.useSelector)((state)=>state.darkMode);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: `relative z-0 ${darkMode ? "bg-black-100" : "bg-white-100"}`,
        children: /*#__PURE__*/ jsx_runtime_.jsx(Project, {})
    });
}


/***/ }),

/***/ 40455:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(71963);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(19751);



const SectionWrapper = (Component, idName)=>function HOC() {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__/* .motion */ .E.section, {
            variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_2__/* .staggerContainer */ .Jm)(Component, idName),
            initial: "hidden",
            whileInView: "show",
            viewport: {
                once: true,
                amount: 0.25
            },
            className: "sm:w-4/5 max-w-7xl ml-auto relative z-0",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "hash-span",
                    id: idName,
                    children: "\xa0"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {})
            ]
        });
    };
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SectionWrapper);


/***/ }),

/***/ 65616:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   metadata: () => (/* binding */ e0)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Users\KURO\Code\bungadi\bungadi-kuro-23\src\app\(user)\project\page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;

const e0 = proxy["metadata"];


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [763,725,332,593,619,206,861,751], () => (__webpack_exec__(72368)));
module.exports = __webpack_exports__;

})();