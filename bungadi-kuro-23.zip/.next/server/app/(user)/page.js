(() => {
var exports = {};
exports.id = 282;
exports.ids = [282];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 89871:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/client");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 71267:
/***/ ((module) => {

"use strict";
module.exports = require("worker_threads");

/***/ }),

/***/ 2027:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(user)',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 88495)), "C:\\Users\\KURO\\Code\\bungadi\\bungadi-kuro-23\\src\\app\\(user)\\page.tsx"],
          
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 93549)), "C:\\Users\\KURO\\Code\\bungadi\\bungadi-kuro-23\\src\\app\\(user)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82819))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 54232)), "C:\\Users\\KURO\\Code\\bungadi\\bungadi-kuro-23\\src\\app\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82819))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\KURO\\Code\\bungadi\\bungadi-kuro-23\\src\\app\\(user)\\page.tsx"];
    
    const originalPathname = "/(user)/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 34905:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 91927))

/***/ }),

/***/ 91927:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/dom/motion.mjs + 202 modules
var motion = __webpack_require__(71963);
// EXTERNAL MODULE: ./node_modules/react-redux/lib/index.js
var lib = __webpack_require__(1560);
// EXTERNAL MODULE: ./node_modules/@react-three/fiber/dist/react-three-fiber.cjs.prod.js
var react_three_fiber_cjs_prod = __webpack_require__(2028);
// EXTERNAL MODULE: ./node_modules/@react-three/drei/index.cjs.js
var index_cjs = __webpack_require__(47320);
// EXTERNAL MODULE: ./src/components/Loader.tsx
var Loader = __webpack_require__(8743);
;// CONCATENATED MODULE: ./src/components/canvas/Laptop.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 




const Computers = ({ isMobile })=>{
    const computer = (0,index_cjs/* useGLTF */.LDd)("./bungadi3d/laptop.gltf");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("mesh", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("hemisphereLight", {
                intensity: 0.15,
                groundColor: "black"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("pointLight", {
                intensity: 0.1
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("spotLight", {
                position: [
                    -20,
                    50,
                    10
                ],
                angle: 0.12,
                penumbra: 1,
                intensity: 1,
                castShadow: true,
                "shadow-mapSize": 1024
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("primitive", {
                object: computer.scene,
                scale: isMobile ? 1.2 : 1.8,
                position: isMobile ? [
                    0,
                    -2.5,
                    0
                ] : [
                    0,
                    -3.5,
                    2
                ],
                rotation: [
                    0,
                    0,
                    0.2
                ]
            })
        ]
    });
};
const LaptopCanvas = ()=>{
    const [isMobile, setIsMobile] = (0,react_.useState)(false);
    (0,react_.useEffect)(()=>{
        // Add a listener for changes to the screen size
        const mediaQuery = window.matchMedia("(max-width: 500px)");
        // Set the initial value of the `isMobile` state variable
        setIsMobile(mediaQuery.matches);
        // Define a callback function to handle changes to the media query
        const handleMediaQueryChange = (event)=>{
            setIsMobile(event.matches);
        };
        // Add the callback function as a listener for changes to the media query
        mediaQuery.addEventListener("change", handleMediaQueryChange);
        // Remove the listener when the component is unmounted
        return ()=>{
            mediaQuery.removeEventListener("change", handleMediaQueryChange);
        };
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_three_fiber_cjs_prod.Canvas, {
        frameloop: "demand",
        shadows: true,
        dpr: [
            1,
            2
        ],
        gl: {
            preserveDrawingBuffer: true
        },
        camera: {
            fov: 45,
            near: 0.1,
            far: 200,
            position: [
                -4,
                6,
                6
            ]
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Suspense, {
                fallback: /*#__PURE__*/ jsx_runtime_.jsx(Loader/* default */.Z, {}),
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(index_cjs/* OrbitControls */.zxs, {
                        autoRotate: true,
                        enableZoom: false,
                        maxPolarAngle: Math.PI / 2,
                        minPolarAngle: Math.PI / 2
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Computers, {
                        isMobile: isMobile
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(index_cjs/* Preload */.qaH, {
                all: true
            })
        ]
    });
};
/* harmony default export */ const Laptop = (LaptopCanvas);

;// CONCATENATED MODULE: ./src/components/Hero.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 




const Hero = ()=>{
    const { darkMode } = (0,lib.useSelector)((state)=>state.darkMode);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "relative w-full sm:w-4/5 h-screen ml-auto",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: `absolute inset-0 top-8 max-w-7xl max-h-fit z-[2] mx-auto
        sm:px-16 px-6 flex flex-row items-start gap-5`,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col justify-center items-center mt-5",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-5 h-5 rounded-full bg-primary"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-1 sm:h-80 h-40 torque-gradient"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: `flex flex-col items-center ${darkMode ? "text-white-100" : "text-black-100"}`,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                                className: `font-black lg:text-6xl sm:text-4xl xs:text-3xl text-3xl mt-2`,
                                children: [
                                    "Hi, I'm ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "text-primary",
                                        children: "Adi"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                className: `font-medium lg:text-3xl sm:text-2xl xs:text-xl text-base mt-2`,
                                children: [
                                    "I'am a Coder who can Design too. ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {
                                        className: "sm:block hidden"
                                    }),
                                    "And welcome to my website"
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-row gap-8 mt-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "/project",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: "mb-2 flex flex-row items-center justify-center gap-2 rounded bg-button-gradien px-6 py-2.5    text-xs font-medium uppercase leading-tight text-white shadow-white    transition duration-150 ease-in-out active:bg-primary-800 active:shadow-lg",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "My Project"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "/blog",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: `mb-2 flex flex-row items-center justify-center gap-2 rounded ${darkMode ? "bg-black-100 shadow-white" : "bg-white-100 shadow-black"} px-6 py-2.5 
                text-xs font-medium uppercase leading-tight text-secondary border-2 border-secondary
                transition duration-150 ease-in-out active:bg-primary-800 active:shadow-lg`,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "Blog"
                                            })
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "mt-4",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    href: "https://drive.google.com/file/d/1aacd3HOVgNqlob7UJqMYHIKEfghLDEid/view?usp=drive_link",
                                    className: "cursor-pointer text-primary hover:text-tertiary",
                                    children: "Download My CV"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.div, {
                className: "h-full w-full",
                children: /*#__PURE__*/ jsx_runtime_.jsx(Laptop, {})
            })
        ]
    });
};
/* harmony default export */ const components_Hero = (Hero);

;// CONCATENATED MODULE: ./src/app/(user)/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



function Home() {
    const { darkMode } = (0,lib.useSelector)((state)=>state.darkMode);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: `relative z-0 ${darkMode ? "bg-black-100" : "bg-white-100"}`,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "bg-hero-pattern bg-cover bg-no-repeat bg-center",
            children: /*#__PURE__*/ jsx_runtime_.jsx(components_Hero, {})
        })
    });
}


/***/ }),

/***/ 88495:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Users\KURO\Code\bungadi\bungadi-kuro-23\src\app\(user)\page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [763,725,332,593,206,861], () => (__webpack_exec__(2027)));
module.exports = __webpack_exports__;

})();