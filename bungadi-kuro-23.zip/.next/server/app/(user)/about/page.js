(() => {
var exports = {};
exports.id = 133;
exports.ids = [133];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 89871:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/client");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 71267:
/***/ ((module) => {

"use strict";
module.exports = require("worker_threads");

/***/ }),

/***/ 49459:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(user)',
        {
        children: [
        'about',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 65029)), "C:\\Users\\KURO\\Code\\bungadi\\bungadi-kuro-23\\src\\app\\(user)\\about\\page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 93549)), "C:\\Users\\KURO\\Code\\bungadi\\bungadi-kuro-23\\src\\app\\(user)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82819))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 54232)), "C:\\Users\\KURO\\Code\\bungadi\\bungadi-kuro-23\\src\\app\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82819))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\KURO\\Code\\bungadi\\bungadi-kuro-23\\src\\app\\(user)\\about\\page.tsx"];
    
    const originalPathname = "/(user)/about/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 23719:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 26907))

/***/ }),

/***/ 26907:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ AboutPage),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/react-tilt/dist/index.js
var dist = __webpack_require__(54619);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/dom/motion.mjs + 202 modules
var motion = __webpack_require__(71963);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/react-redux/lib/index.js
var lib = __webpack_require__(1560);
// EXTERNAL MODULE: ./src/utils/constants.ts
var constants = __webpack_require__(49711);
// EXTERNAL MODULE: ./src/hoc/SectionWrapper.tsx
var SectionWrapper = __webpack_require__(40455);
// EXTERNAL MODULE: ./src/utils/motion.ts
var utils_motion = __webpack_require__(19751);
;// CONCATENATED MODULE: ./src/components/About.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 








const ServiceCard = ({ index, title, icon, dark })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(dist/* Tilt */.C, {
        className: " sm:w-40 w-full",
        children: /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.div, {
            variants: (0,utils_motion/* fadeIn */.Ji)("right", "spring", index * 0.5, 0.75),
            className: `w-full green-blue-gradient p-px rounded-[20px] ${dark ? "shadow-card1" : "shadow-card0"}`,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: `${dark ? "bg-black-100" : "bg-white-100"} rounded-[20px] py-1 px-12 min-h-[280px] flex justify-evenly items-center flex-col`,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: icon,
                        width: 10,
                        height: 10,
                        alt: "web-development",
                        className: "w-16 h-16 object-contain"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        className: `${dark ? "text-white-100" : "text-black-100"} text-[20px] font-bold text-center`,
                        children: title
                    })
                ]
            })
        })
    });
};
const About = ()=>{
    const { darkMode } = (0,lib.useSelector)((state)=>state.darkMode);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `sm:px-16 px-6 mt-8 ${darkMode ? "text-white-100" : "text-black-100"}`,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion */.E.div, {
                variants: (0,utils_motion/* textVariant */.wt)(0.5),
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "font-medium lg:text-2xl sm:text-xl xs:text-lg text-base mt-2",
                        children: "Introduction"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "font-black lg:text-5xl sm:text-3xl xs:text-2xl text-xl mt-2",
                        children: "Overview."
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.p, {
                variants: (0,utils_motion/* fadeIn */.Ji)("", "", 0.1, 1),
                className: "mt-4 text-[17px] max-w-3xl leading-[30px]",
                children: "I'm a skilled software developer with experience in TypeScript and JavaScript, and expertise in frameworks like React, Node.js, and Three.js. I'm a quick learner and collaborate closely with clients to create efficient, scalable, and user-friendly solutions that solve real-world problems. Let's work together to bring your ideas to life!"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "sm:mt-16 mt-8 flex flex-wrap justify-center gap-10",
                children: constants/* services */.uZ.map((service, index)=>/*#__PURE__*/ jsx_runtime_.jsx(ServiceCard, {
                        index: index,
                        ...service,
                        dark: darkMode
                    }, service.title))
            })
        ]
    });
};
/* harmony default export */ const components_About = ((0,SectionWrapper/* default */.Z)(About, "about"));

// EXTERNAL MODULE: ./node_modules/react-vertical-timeline-component/dist-modules/index.js
var dist_modules = __webpack_require__(77142);
// EXTERNAL MODULE: ./node_modules/react-vertical-timeline-component/style.min.css
var style_min = __webpack_require__(65119);
;// CONCATENATED MODULE: ./src/components/Exp.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 









const ExperienceCard = ({ experience, dark })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dist_modules.VerticalTimelineElement, {
        contentStyle: {
            background: "#1d1836",
            color: "#fff"
        },
        contentArrowStyle: {
            borderRight: "7px solid  #232631"
        },
        dateClassName: `${dark ? "text-white-100" : "text-black-100"}`,
        date: experience.date,
        iconStyle: {
            background: experience.iconBg
        },
        icon: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "flex justify-center items-center w-full h-full",
            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                src: experience.icon,
                width: 10,
                height: 10,
                alt: experience.company_name,
                className: "w-[60%] h-[60%] object-contain"
            })
        }),
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        className: "text-white text-[24px] font-bold",
                        children: experience.title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-secondary text-[16px] font-semibold m-0",
                        children: experience.company_name
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                className: "mt-5 list-disc ml-5 space-y-2",
                children: experience.points.map((point, index)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: "text-white-100 text-[14px] pl-1 tracking-wider",
                        children: point
                    }, `experience-point-${index}`))
            })
        ]
    });
};
const Experience = ()=>{
    const { darkMode } = (0,lib.useSelector)((state)=>state.darkMode);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `sm:px-16 px-6 mt-8 ${darkMode ? "text-white-100" : "text-black-100"}`,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion */.E.div, {
                variants: (0,utils_motion/* textVariant */.wt)(0.5),
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "font-medium lg:text-2xl sm:text-xl xs:text-lg text-base mt-2 text-center",
                        children: "What I have done so far"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "font-black lg:text-5xl sm:text-3xl xs:text-2xl text-xl mt-2 text-center",
                        children: "Work Experience."
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "mt-4 flex flex-col",
                children: /*#__PURE__*/ jsx_runtime_.jsx(dist_modules.VerticalTimeline, {
                    lineColor: darkMode ? "white" : "black",
                    children: constants/* experiences */.kw.map((experience, index)=>/*#__PURE__*/ jsx_runtime_.jsx(ExperienceCard, {
                            experience: experience,
                            dark: darkMode
                        }, `experience-${index}`))
                })
            })
        ]
    });
};
/* harmony default export */ const Exp = ((0,SectionWrapper/* default */.Z)(Experience, "work"));

// EXTERNAL MODULE: ./node_modules/@react-three/fiber/dist/react-three-fiber.cjs.prod.js
var react_three_fiber_cjs_prod = __webpack_require__(2028);
// EXTERNAL MODULE: ./node_modules/@react-three/drei/index.cjs.js
var index_cjs = __webpack_require__(47320);
// EXTERNAL MODULE: ./src/components/Loader.tsx
var Loader = __webpack_require__(8743);
;// CONCATENATED MODULE: ./src/components/canvas/Ball.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 




const Ball = ({ imgUrl })=>{
    const [decal] = (0,index_cjs/* useTexture */.mE8)([
        imgUrl
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(index_cjs/* Float */.bvt, {
        speed: 1.75,
        rotationIntensity: 1,
        floatIntensity: 2,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("ambientLight", {
                intensity: 0.25
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("directionalLight", {
                position: [
                    0,
                    0,
                    0.05
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("mesh", {
                castShadow: true,
                receiveShadow: true,
                scale: 2.75,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("icosahedronGeometry", {
                        args: [
                            1,
                            1
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meshStandardMaterial", {
                        color: "#EEEEEE",
                        polygonOffset: true,
                        polygonOffsetFactor: -5,
                        flatShading: true
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(index_cjs/* Decal */._ic, {
                        position: [
                            0,
                            0,
                            1
                        ],
                        rotation: [
                            2 * Math.PI,
                            0,
                            6.25
                        ],
                        scale: 1,
                        map: decal
                    })
                ]
            })
        ]
    });
};
const BallCanvas = ({ icon })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_three_fiber_cjs_prod.Canvas, {
        frameloop: "demand",
        dpr: [
            1,
            2
        ],
        gl: {
            preserveDrawingBuffer: true
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Suspense, {
                fallback: /*#__PURE__*/ jsx_runtime_.jsx(Loader/* default */.Z, {}),
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(index_cjs/* OrbitControls */.zxs, {
                        enableZoom: false
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Ball, {
                        imgUrl: icon
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(index_cjs/* Preload */.qaH, {
                all: true
            })
        ]
    });
};
/* harmony default export */ const canvas_Ball = (BallCanvas);

;// CONCATENATED MODULE: ./src/components/ToolSkill.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 





const Tech = ()=>{
    const { darkMode } = (0,lib.useSelector)((state)=>state.darkMode);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `sm:px-16 px-6 mt-8 ${darkMode ? "text-white-100" : "text-black-100"}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                    className: "font-black lg:text-5xl sm:text-3xl xs:text-2xl text-xl mt-2 mb-4 text-center",
                    children: "Tools & Skill."
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex flex-row flex-wrap justify-center gap-8",
                children: constants/* technologies */.RJ.map((technology)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-28 h-28",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(canvas_Ball, {
                            icon: technology.icon
                        })
                    }, technology.name))
            })
        ]
    });
};
/* harmony default export */ const ToolSkill = ((0,SectionWrapper/* default */.Z)(Tech, ""));

;// CONCATENATED MODULE: ./src/app/(user)/about/page.tsx
/* __next_internal_client_entry_do_not_use__ metadata,default auto */ 





const metadata = {
    title: "Who is 'Adi' Muhammad Aziz Abdillah"
};
function AboutPage() {
    const { darkMode } = (0,lib.useSelector)((state)=>state.darkMode);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `relative z-0 ${darkMode ? "bg-black-100" : "bg-white-100"}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(components_About, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Exp, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(ToolSkill, {})
        ]
    });
}


/***/ }),

/***/ 40455:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(71963);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(19751);



const SectionWrapper = (Component, idName)=>function HOC() {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__/* .motion */ .E.section, {
            variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_2__/* .staggerContainer */ .Jm)(Component, idName),
            initial: "hidden",
            whileInView: "show",
            viewport: {
                once: true,
                amount: 0.25
            },
            className: "sm:w-4/5 max-w-7xl ml-auto relative z-0",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "hash-span",
                    id: idName,
                    children: "\xa0"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {})
            ]
        });
    };
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SectionWrapper);


/***/ }),

/***/ 65029:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   metadata: () => (/* binding */ e0)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Users\KURO\Code\bungadi\bungadi-kuro-23\src\app\(user)\about\page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;

const e0 = proxy["metadata"];


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [763,725,332,593,619,198,483,206,861,751], () => (__webpack_exec__(49459)));
module.exports = __webpack_exports__;

})();