"use strict";
exports.id = 687;
exports.ids = [687];
exports.modules = {

/***/ 75422:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ lib_urlFor)
});

// EXTERNAL MODULE: ./node_modules/next-sanity/dist/index.cjs.js
var index_cjs = __webpack_require__(94680);
;// CONCATENATED MODULE: ./src/lib/sanity.client.ts

// import {createClient, type SanityClient} from 'next-sanity'
const projectId = "1hckirf8";
const dataset = "production";
const apiVersion = "2023-06-20";
const useCdn = true;
const client = (0,index_cjs/* createClient */.eI)({
    apiVersion,
    dataset,
    projectId,
    useCdn
});

// EXTERNAL MODULE: ./node_modules/@sanity/image-url/lib/node/index.js
var node = __webpack_require__(69361);
var node_default = /*#__PURE__*/__webpack_require__.n(node);
;// CONCATENATED MODULE: ./src/lib/urlFor.ts


const builder = node_default()(client);
function urlFor(source) {
    return builder.image(source);
}
/* harmony default export */ const lib_urlFor = (urlFor);


/***/ }),

/***/ 49002:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Lp: () => (/* binding */ client)
/* harmony export */ });
/* unused harmony exports projectId, dataset, apiVersion, useCdn */
/* harmony import */ var next_sanity__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(59407);

// import {createClient, type SanityClient} from 'next-sanity'
const projectId = "1hckirf8";
const dataset = "production";
const apiVersion = "2023-06-20";
const useCdn = true;
const client = (0,next_sanity__WEBPACK_IMPORTED_MODULE_0__/* .createClient */ .eI)({
    apiVersion,
    dataset,
    projectId,
    useCdn
});


/***/ })

};
;