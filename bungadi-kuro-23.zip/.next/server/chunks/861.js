exports.id = 861;
exports.ids = [861];
exports.modules = {

/***/ 45344:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 13180));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 32021))

/***/ }),

/***/ 8743:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _react_three_drei__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(47320);


const CanvasLoader = ()=>{
    const { progress } = (0,_react_three_drei__WEBPACK_IMPORTED_MODULE_1__/* .useProgress */ .SEm)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_three_drei__WEBPACK_IMPORTED_MODULE_1__/* .Html */ .Vtq, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "canvas-loader"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                style: {
                    fontSize: 14,
                    color: "#F1F1F1",
                    fontWeight: 800,
                    marginTop: 40
                },
                children: [
                    progress.toFixed(2),
                    "%"
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CanvasLoader);


/***/ }),

/***/ 32021:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ components_Navbar)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/react-redux/lib/index.js
var lib = __webpack_require__(1560);
// EXTERNAL MODULE: ./src/redux/slices/darkModeSlice.ts
var darkModeSlice = __webpack_require__(61744);
// EXTERNAL MODULE: ./src/redux/slices/whatPageSlice.ts
var whatPageSlice = __webpack_require__(80462);
// EXTERNAL MODULE: ./node_modules/react-icons/bs/index.esm.js
var index_esm = __webpack_require__(75484);
// EXTERNAL MODULE: ./src/utils/constants.ts
var constants = __webpack_require__(49711);
// EXTERNAL MODULE: ./node_modules/@react-three/fiber/dist/react-three-fiber.cjs.prod.js
var react_three_fiber_cjs_prod = __webpack_require__(2028);
// EXTERNAL MODULE: ./node_modules/@react-three/drei/index.cjs.js
var index_cjs = __webpack_require__(47320);
// EXTERNAL MODULE: ./src/components/Loader.tsx
var Loader = __webpack_require__(8743);
;// CONCATENATED MODULE: ./src/components/canvas/Logo.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 




const BungAdiLogo = ()=>{
    const file = (0,index_cjs/* useGLTF */.LDd)("./bungadi3d/logo.gltf");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("mesh", {
        castShadow: true,
        receiveShadow: true,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("ambientLight", {
                intensity: 0.25
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("directionalLight", {
                position: [
                    0,
                    0,
                    0.05
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("primitive", {
                object: file.scene,
                scale: 3,
                position: [
                    0,
                    -3,
                    0
                ],
                rotation: [
                    0,
                    0,
                    0
                ]
            })
        ]
    });
};
const LogoCanvas = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_three_fiber_cjs_prod.Canvas, {
        shadows: true,
        frameloop: "demand",
        dpr: [
            1,
            2
        ],
        gl: {
            preserveDrawingBuffer: true
        },
        camera: {
            fov: 45,
            near: 0.1,
            far: 200,
            position: [
                -4,
                3,
                6
            ]
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Suspense, {
                fallback: /*#__PURE__*/ jsx_runtime_.jsx(Loader/* default */.Z, {}),
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(index_cjs/* OrbitControls */.zxs, {
                        autoRotate: true,
                        enableZoom: false,
                        maxPolarAngle: Math.PI / 2,
                        minPolarAngle: Math.PI / 2
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(BungAdiLogo, {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(index_cjs/* Preload */.qaH, {
                all: true
            })
        ]
    });
};
/* harmony default export */ const Logo = (LogoCanvas);

// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/dom/motion.mjs + 202 modules
var motion = __webpack_require__(71963);
;// CONCATENATED MODULE: ./src/components/Navbar.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 










const menu = "/assets/menu.svg";
const Navbar_close = "/assets/close.svg";
const Navbar = ()=>{
    const [toggle, setToggle] = (0,react_.useState)(true);
    const { darkMode } = (0,lib.useSelector)((state)=>state.darkMode);
    const currentPage = (0,lib.useSelector)((state)=>state.currentPage);
    const dispatch = (0,lib.useDispatch)();
    (0,react_.useEffect)(()=>{
        const mediaQuery = window.matchMedia("(min-width: 640px)");
        setToggle(mediaQuery.matches);
        const handleMediaQueryChange = (event)=>{
            setToggle(event.matches);
        };
        mediaQuery.addEventListener("change", handleMediaQueryChange);
        return ()=>{
            mediaQuery.removeEventListener("change", handleMediaQueryChange);
        };
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                id: "sidenav-1",
                className: `fixed left-0 top-0 z-20 h-full w-1/2 sm:w-1/5 -translate-x-full 
    overflow-hidden ${darkMode ? "bg-black-100 shadow-white" : "bg-white-100 shadow-black"} data-[te-sidenav-hidden='false']:translate-x-0`,
                "data-te-sidenav-init": true,
                "data-te-sidenav-hidden": `${!toggle ? "true" : "false"}`,
                "data-te-sidenav-position": "absolute",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "relative w-full h-full flex flex-col justify-start items-center my-4 gap-8",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                            href: "/",
                            className: "flex items-center flex-col",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.div, {
                                    className: " h-32 w-32",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Logo, {})
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    className: `${darkMode ? "text-white-100" : "text-black-100"} text-[18px] font-bold cursor-pointer flex`,
                                    children: [
                                        "bungadi.com \xa0",
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "xl:block hidden",
                                            children: " | by Adi"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                            className: "relative list-none flex flex-col gap-2",
                            children: constants/* navLinks */.FV.map((nav)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: `${currentPage === nav.title ? "text-primary" : `${darkMode ? "text-white-100" : "text-black-100"}`} hover:text-secondary hover:scale-105 text-[18px] font-medium cursor-pointer`,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: `/${nav.id}`,
                                        onClick: ()=>dispatch((0,whatPageSlice/* setCurrentPage */.D)(`${nav.title}`)),
                                        children: nav.title
                                    })
                                }, nav.id))
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex justify-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    type: "checkbox",
                                    className: "absolute opacity-0",
                                    id: "checkbox-darkmode",
                                    role: "switch",
                                    checked: darkMode,
                                    onChange: ()=>dispatch((0,darkModeSlice/* toggleDarkMode */.I)())
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                    htmlFor: "checkbox-darkmode",
                                    className: `flex w-12 h-5 rounded-3xl items-center justify-between relative scale-150 cursor-pointer ${darkMode ? "shadow-inset0" : "shadow-inset1"}`,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsMoonStarsFill */.gxG, {
                                            color: "white"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsFillSunFill */.UD2, {
                                            color: "yellow"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: `w-5 h-5 bg-secondary absolute top-[1] left-[1] rounded-3xl transition-transform 
            ${darkMode ? "translate-x-8" : "translate-x-0"}`
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "sm:hidden fixed bottom-0 z-30 w-full",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex flex-row items-center justify-center w-full",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                        className: " mb-2 flex flex-row items-center justify-center gap-2 rounded bg-button-gradien px-6 py-2.5    text-xs font-medium uppercase leading-tight text-white shadow-white    transition duration-150 ease-in-out active:bg-primary-800 active:shadow-lg",
                        onClick: ()=>setToggle(!toggle),
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: toggle ? Navbar_close : menu,
                                width: 10,
                                height: 10,
                                alt: "menu",
                                className: "w-[28px] h-[28px] object-contain"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Menu"
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const components_Navbar = (Navbar);


/***/ }),

/***/ 13180:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  DefaultProviders: () => (/* binding */ DefaultProviders)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/react-redux/lib/index.js
var lib = __webpack_require__(1560);
// EXTERNAL MODULE: ./node_modules/redux-persist/lib/integration/react.js
var react = __webpack_require__(57370);
// EXTERNAL MODULE: ./node_modules/redux-persist/lib/index.js
var redux_persist_lib = __webpack_require__(47698);
// EXTERNAL MODULE: ./node_modules/@reduxjs/toolkit/dist/redux-toolkit.cjs.production.min.js
var redux_toolkit_cjs_production_min = __webpack_require__(10668);
// EXTERNAL MODULE: ./node_modules/redux-persist/lib/storage/index.js
var storage = __webpack_require__(35292);
// EXTERNAL MODULE: ./src/redux/slices/darkModeSlice.ts
var darkModeSlice = __webpack_require__(61744);
// EXTERNAL MODULE: ./src/redux/slices/whatPageSlice.ts
var whatPageSlice = __webpack_require__(80462);
;// CONCATENATED MODULE: ./src/redux/store/store.ts





const persistConfig = {
    key: "root",
    storage: storage/* default */.Z
};
function makeStore() {
    return (0,redux_toolkit_cjs_production_min.configureStore)({
        reducer: {
            darkMode: (0,redux_persist_lib.persistReducer)(persistConfig, darkModeSlice/* default */.Z),
            navigation: (0,redux_persist_lib.persistReducer)(persistConfig, whatPageSlice/* default */.Z)
        },
        middleware: (getDefaultMiddleware)=>getDefaultMiddleware({
                serializableCheck: {
                    // Ignore these action types
                    ignoredActions: [
                        redux_persist_lib.FLUSH,
                        redux_persist_lib.REHYDRATE,
                        redux_persist_lib.PAUSE,
                        redux_persist_lib.PERSIST,
                        redux_persist_lib.PURGE,
                        redux_persist_lib.REGISTER
                    ],
                    // Ignore these field paths in all actions
                    ignoredActionPaths: [
                        "meta.arg",
                        "payload.timestamp"
                    ],
                    // Ignore these paths in the state
                    ignoredPaths: [
                        "items.dates"
                    ]
                }
            })
    });
}
const store = makeStore();

;// CONCATENATED MODULE: ./src/redux/provider.tsx
/* __next_internal_client_entry_do_not_use__ DefaultProviders auto */ 




const persistor = (0,redux_persist_lib.persistStore)(store);
function DefaultProviders({ children }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(lib.Provider, {
        store: store,
        children: /*#__PURE__*/ jsx_runtime_.jsx(react/* PersistGate */.r, {
            loading: null,
            persistor: persistor,
            children: children
        })
    });
}


/***/ }),

/***/ 61744:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   I: () => (/* binding */ toggleDarkMode),
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(10668);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    darkMode: true
};
const darkModeSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "darkMode",
    initialState,
    reducers: {
        toggleDarkMode: (state)=>{
            state.darkMode = !state.darkMode;
        }
    }
});
const { toggleDarkMode } = darkModeSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (darkModeSlice.reducer);


/***/ }),

/***/ 80462:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   D: () => (/* binding */ setCurrentPage),
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(10668);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    currentPage: "home"
};
const navigationSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "currentPage",
    initialState,
    reducers: {
        setCurrentPage (state, action) {
            state.currentPage = action.payload;
        }
    }
});
const { setCurrentPage } = navigationSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (navigationSlice.reducer);


/***/ }),

/***/ 49711:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FV: () => (/* binding */ navLinks),
/* harmony export */   RJ: () => (/* binding */ technologies),
/* harmony export */   kw: () => (/* binding */ experiences),
/* harmony export */   q: () => (/* binding */ projects),
/* harmony export */   uZ: () => (/* binding */ services)
/* harmony export */ });
/* unused harmony export testimonials */
const mobile = "/assets/mobile.png";
const backend = "/assets/backend.png";
const creator = "/assets/creator.png";
const web = "/assets/web.png";
const javascript = "/assets/tech/javascript.png";
const typescript = "/assets/tech/typescript.png";
const html = "/assets/tech/html.png";
const css = "/assets/tech/css.png";
const reactjs = "/assets/tech/reactjs.png";
const redux = "/assets/tech/redux.png";
const tailwind = "/assets/tech/tailwind.png";
const nodejs = "/assets/tech/nodejs.png";
const mongodb = "/assets/tech/mongodb.png";
const git = "/assets/tech/git.png";
const figma = "/assets/tech/figma.png";
const docker = "/assets/tech/docker.png";
const kodingnext = "/assets/company/Kodingnext.png";
const blank = "/assets/company/blank.png";
const bawp = "/assets/ba-wp.png";
const baone = "/assets/ba-one.png";
const tenzies = "/assets/tenzies.png";
const threejs = "/assets/tech/threejs.svg";
const navLinks = [
    // {
    //   id: "home",
    //   title: "Home",
    //   link: "./",
    // },
    {
        id: "about",
        title: "About"
    },
    {
        id: "project",
        title: "Project"
    },
    {
        id: "blog",
        title: "Blog"
    },
    {
        id: "contact",
        title: "Contact"
    }
];
const services = [
    {
        title: "Web Developer",
        icon: web
    },
    // {
    //   title: "React Native Developer",
    //   icon: mobile,
    // },
    {
        title: "Backend Developer",
        icon: backend
    },
    {
        title: "Web Designer",
        icon: creator
    }
];
const technologies = [
    {
        name: "HTML 5",
        icon: html
    },
    {
        name: "CSS 3",
        icon: css
    },
    {
        name: "JavaScript",
        icon: javascript
    },
    {
        name: "TypeScript",
        icon: typescript
    },
    {
        name: "React JS",
        icon: reactjs
    },
    {
        name: "Redux Toolkit",
        icon: redux
    },
    {
        name: "Tailwind CSS",
        icon: tailwind
    },
    {
        name: "Node JS",
        icon: nodejs
    },
    {
        name: "MongoDB",
        icon: mongodb
    },
    {
        name: "Three JS",
        icon: threejs
    },
    {
        name: "git",
        icon: git
    },
    {
        name: "figma",
        icon: figma
    }
];
const experiences = [
    {
        title: "Web Designer Intern",
        company_name: "DNAstudio.web.id",
        icon: blank,
        iconBg: "#383E56",
        date: "August 2016 - July 2017",
        points: [
            "After I clear my course here. I help them in many jobs.",
            "Like doing meetings and briefi ng with clients.",
            "Help staff there with designing the website and training students there"
        ]
    },
    {
        title: "Web Designer",
        company_name: "Freelance",
        icon: blank,
        iconBg: "#383E56",
        date: "December 2020 - Present",
        points: [
            "In general, what I do is web design.",
            "But I actually do graphic design, logo design, printing design, andpresentation design too.",
            "I successfully build good relationships with some small businesses and content creators.",
            "My design process depends on the timeline is."
        ]
    },
    {
        title: "Advance Coding Teacher (PT)",
        company_name: "Koding next",
        icon: kodingnext,
        iconBg: "#383E56",
        date: "August 2022 - June 2023",
        points: [
            "My job there is to teach coding for kids in class 1-3 grade schooler.",
            "And also early teenager betwen 12 - 17 Junior Hight to Senior Hight",
            "What I teach is 2d games with Scratch, Tynker, some basic Python, and some basic HTML - CSS too"
        ]
    }
];
const testimonials = [
    {
        testimonial: "I thought it was impossible to make a website as beautiful as our product, but Rick proved me wrong.",
        name: "Sara Lee",
        designation: "CFO",
        company: "Acme Co",
        image: "https://randomuser.me/api/portraits/women/4.jpg"
    },
    {
        testimonial: "I've never met a web developer who truly cares about their clients' success like Rick does.",
        name: "Chris Brown",
        designation: "COO",
        company: "DEF Corp",
        image: "https://randomuser.me/api/portraits/men/5.jpg"
    }
];
const projects = [
    {
        name: "bungadi theme wordpress 20xx",
        description: "this was the wordpress theme my website used in (I forgot when was it's created) last ting I know in early 2023 I am not use it again",
        tags: [
            {
                name: "PHP",
                color: "blue-text-gradient"
            },
            {
                name: "wordpress",
                color: "green-text-gradient"
            },
            {
                name: "custom-theme",
                color: "pink-text-gradient"
            }
        ],
        image: bawp,
        source_code_link: "https://github.com/Bung-Adi/bungadi-theme-wordpress-20xx"
    },
    {
        name: "My first react website",
        description: "this is my first react headless wordpress cms that's was ever used in this domain",
        tags: [
            {
                name: "react",
                color: "blue-text-gradient"
            },
            {
                name: "graphql",
                color: "green-text-gradient"
            },
            {
                name: "wordpress",
                color: "pink-text-gradient"
            }
        ],
        image: baone,
        source_code_link: "https://github.com/Bung-Adi/bungadi-front-end-2022"
    },
    {
        name: "Tenzies Game React",
        description: "Simple project but quite use logical thinking. It was a project for my learning with some customization from the original example",
        tags: [
            {
                name: "react",
                color: "blue-text-gradient"
            },
            {
                name: "logic",
                color: "green-text-gradient"
            }
        ],
        image: tenzies,
        source_code_link: "https://github.com/Bung-Adi/Tenzies-Game-React"
    }
];



/***/ }),

/***/ 93549:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ RootLayout),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"src\\app\\(user)\\layout.tsx","import":"Inter","arguments":[{"subsets":["latin"]}],"variableName":"inter"}
var target_path_src_app_user_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_ = __webpack_require__(26735);
var target_path_src_app_user_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_default = /*#__PURE__*/__webpack_require__.n(target_path_src_app_user_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(21313);
;// CONCATENATED MODULE: ./src/redux/provider.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\KURO\Code\bungadi\bungadi-kuro-23\src\redux\provider.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;

const e0 = proxy["DefaultProviders"];

// EXTERNAL MODULE: ./src/app/globals.css
var globals = __webpack_require__(75553);
;// CONCATENATED MODULE: ./src/components/Navbar.tsx

const Navbar_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\KURO\Code\bungadi\bungadi-kuro-23\src\components\Navbar.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: Navbar_esModule, $$typeof: Navbar_$$typeof } = Navbar_proxy;
const Navbar_default_ = Navbar_proxy.default;


/* harmony default export */ const Navbar = (Navbar_default_);
;// CONCATENATED MODULE: ./src/app/(user)/layout.tsx





const metadata = {
    title: {
        default: "bungadi.com",
        template: "%s | bungadi.com"
    },
    description: "Portfolio and Blog of 'Adi' Muhammad Aziz Abdillah. An Indonesian coder thats understand design",
    openGraph: {
        title: "bungadi.com",
        description: "Portfolio and Blog of 'Adi' Muhammad Aziz Abdillah. An Indonesian coder thats understand design",
        url: "bungadi.com",
        siteName: "bungadi.com",
        images: [
            {
                url: "/preview-sm.jpg",
                width: 800,
                height: 600
            },
            {
                url: "/preview.jpg",
                width: 1800,
                height: 1600,
                alt: "My custom alt"
            }
        ],
        type: "website"
    },
    robots: {
        index: false,
        follow: true,
        nocache: true,
        googleBot: {
            index: true,
            follow: false,
            noimageindex: true,
            "max-video-preview": -1,
            "max-image-preview": "large",
            "max-snippet": -1
        }
    }
};
function RootLayout({ children }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("html", {
        lang: "en",
        suppressHydrationWarning: true,
        children: /*#__PURE__*/ jsx_runtime_.jsx("body", {
            className: (target_path_src_app_user_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_default()).className,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(e0, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Navbar, {}),
                    children
                ]
            })
        })
    });
}


/***/ })

};
;